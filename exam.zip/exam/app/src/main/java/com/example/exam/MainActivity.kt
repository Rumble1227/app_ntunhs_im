package com.example.exam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.widget.DecorContentParent


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val SpnOrderB = findViewById<Spinner>(R.id.SpnOrderB)
        val SpnOrderS = findViewById<Spinner>(R.id.SpnOrderS)
        val adapter = ArrayAdapter.createFromResource(this,R.array.Order1,
            android.R.layout.simple_spinner_dropdown_item)
        val btnChangeActivity = findViewById<Button>(R.id.btnChangeActivity)
        val PhoneNum = findViewById<TextView>(R.id.PhoneNum)
        val ckb1 =findViewById<CheckBox>(R.id.ckb1)
        val ckb2 =findViewById<CheckBox>(R.id.ckb2)
        SpnOrderB.adapter =adapter
        SpnOrderS.adapter = adapter

        var selectedOrderB = ""
        var selectedOrderS = ""
        var extras = ""

        SpnOrderB.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, pos:Int, id:Long)
            {
                val OrderBig = resources.getStringArray(R.array.Order1)
                if(pos>0)
                    selectedOrderB = OrderBig[pos]

            }
            override fun onNothingSelected(parent: AdapterView<*>){
            }
        }

        SpnOrderS.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, pos:Int, id:Long)
            {
                val OrderSmall = resources.getStringArray(R.array.Order2)
                if(pos>0)
                    selectedOrderS = OrderSmall[pos]

            }
            override fun onNothingSelected(parent: AdapterView<*>){
            }
        }

        btnChangeActivity.setOnClickListener{
            if (ckb1.isChecked)
                extras += "兒童椅\n"
            if (ckb2.isChecked)
                extras += "兒童餐具\n"

            var name =  PhoneNum.text.toString()
            val bundle = Bundle().apply {
                putString("name",name)
                putString("selectedOrderB",selectedOrderB)
                putString("selectedOrderS",selectedOrderS)
                putString("extras", extras)
            }

            Log.e("MainActivity", "selectedOrderB:$selectedOrderB")
            Log.e("MainActivity", "selectedOrderS:$selectedOrderS")
            Log.e("MainActivity", "extras:$extras")
            Log.e("MainActivity", "PhoneNum:$name")
            bundle.putString("name",name)
            var seconIntent = Intent(this,exam2::class.java)
            seconIntent.putExtra("key",bundle)
            startActivity(seconIntent)
        }



    }
}