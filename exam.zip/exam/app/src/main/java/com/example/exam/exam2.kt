package com.example.exam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class exam2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exam2)
        val txttext = findViewById<TextView>(R.id.txttext)
        val bundle = intent.getBundleExtra("key")
        val name = bundle?.getString("name")
        val selectedOrderB = bundle?.getString("selectedOrderB")
        val selectedOrderS = bundle?.getString("selectedOrderS")
        val extras = bundle?.getString("extras")

        val message = "$selectedOrderB:大 \n $selectedOrderS:小"

        val btnBacktoFirst = findViewById<Button>(R.id.btnBacktoFirst)
        val text =intent.getBundleExtra("key")?.getString("name").toString()

        txttext.text = "訂位電話:" +name +"\n訂位人數"+ "$selectedOrderB 大  $selectedOrderS 小" +"\n需要:$extras"



            btnBacktoFirst.setOnClickListener{
                var mainIntent = Intent(this,MainActivity::class.java)
                startActivity(mainIntent)
                finish()
        }
    }
}