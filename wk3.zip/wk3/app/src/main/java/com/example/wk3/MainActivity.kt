package com.example.wk3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import android.widget.RadioButton
import android.widget.CheckBox
import com.example.wk3.R

import java.util.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val editTextText2 = findViewById<TextView>(R.id.editTextText2)
        val editTextTextPassword = findViewById<TextView>(R.id.editTextTextPassword)
        val editTextTextEmailAddress = findViewById<TextView>(R.id.editTextTextEmailAddress)

        val Group = findViewById<RadioGroup>(R.id.Group)
        val editTextPhone = findViewById<TextView>(R.id.editTextPhone)
        val radioButton = findViewById<RadioButton>(R.id.radioButton)
        val radioButton2 = findViewById<RadioButton>(R.id.radioButton2)
        val radioButton3 = findViewById<RadioButton>(R.id.radioButton3)
        val ckb1 = findViewById<CheckBox>(R.id.ckb1)
        val ckb2 = findViewById<CheckBox>(R.id.ckb2)
        val ckb3 = findViewById<CheckBox>(R.id.ckb3)
        val ckb4 = findViewById<CheckBox>(R.id.ckb4)
        val btn_send = findViewById<Button>(R.id.btn_send)

        val adapter = ArrayAdapter.createFromResource(
            this, R.array.city, android.R.layout
                .simple_spinner_dropdown_item
        )

        btn_send.setOnClickListener{
            var msg = ""

            if (ckb1.isChecked())
            {
                msg = msg + ckb1.getText().toString()
            }

            if (ckb2.isChecked())
            {
                msg = msg + " " + ckb2.getText().toString()
            }

            if (ckb3.isChecked())
            {
                msg = msg + " " + ckb3.getText().toString()
            }
            if (ckb4.isChecked())
            {
                msg = msg +""+ckb4.getText().toString()
            }
            Toast.makeText(this@MainActivity,  ""+msg, Toast.LENGTH_SHORT).show()
        }

        Group.setOnCheckedChangeListener()
        { _, checkedId ->
            var gender = when (checkedId) {
                R.id.radioButton -> radioButton.text.toString()
                R.id.radioButton2 -> radioButton2.text.toString()
                R.id.radioButton3 -> radioButton3.text.toString()
                else -> "我不知道"
            }
            Toast.makeText(this,gender,Toast.LENGTH_SHORT).show()
        }
    }
}