package com.example.hw5

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class SecondActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val btnBacktoFirst = findViewById<Button>(R.id.btnBacktoFirst)
        val txttest = findViewById<TextView>(R.id.txttest)
        val text = intent.getBundleExtra("key")?.getString("name").toString()
        val textView = findViewById<TextView>(R.id.textView2)
        val textView4 = findViewById<TextView>(R.id.textView4)
        val guess_button = findViewById<Button>(R.id.guess_button)
        val reset_button = findViewById<Button>(R.id.reset_button)
        val editText = findViewById<EditText>(R.id.editText)
        var validate_num: Int
        val secret: Int = Random().nextInt(100) + 1
        var MAX = 100
        var min = 1
        txttest.setText(text)

        btnBacktoFirst.setOnClickListener {
            finish()
        }


        guess_button.setOnClickListener {

            textView.text=editText.text
            Toast.makeText(this,editText.text,Toast.LENGTH_LONG)
            validate_num = editText.text.toString().toInt()
            var ans_str: String = " "

            if(validate_num == secret)
            {
                ans_str="猜對"
            }

            else if(validate_num > secret)
            {
                MAX = validate_num -1
                ans_str="太大"
                textView.text ="區間: $min ~ $MAX"

            }
            else {
                if(validate_num < secret) {
                    min = validate_num +1
                    ans_str = "太小"
                    textView.text  ="區間 $min ~ $MAX"
                }
            }
            reset_button.setOnClickListener {
                val secret = Random().nextInt(100)+1
                textView.text="Reset"

            }
            textView4.text = ans_str

        }
    }

    var lastTime: Long =0
    override fun finish() {
        val currentTime = System.currentTimeMillis()
        if(currentTime - lastTime > 3*1000){
            lastTime = currentTime
            Toast.makeText(this , "再按一下離開", Toast.LENGTH_SHORT).show()
        }
        else
        {
            super.finish()
        }
    }
}